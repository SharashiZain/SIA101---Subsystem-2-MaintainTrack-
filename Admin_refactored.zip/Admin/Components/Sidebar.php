<?php
/* ------------------------------------------------------------
   ADMIN SIDEBAR
   ------------------------------------------------------------ */
?>
<link rel="stylesheet" href="../../Components/css/Sidebar.css">

<aside class="role-sidebar" data-layout-role="admin" aria-label="Admin navigation">
    <a class="sidebar-brand" href="Dashboard.php">
        <span class="sidebar-brand-mark" aria-hidden="true">M</span>
        <span>MaintainTrack</span>
    </a>

    <nav class="sidebar-menu" aria-label="Main navigation">
        <?php foreach ($menuItems as $item): ?>
            <a class="menu-item" href="<?= htmlspecialchars($item['href']) ?>" data-page="<?= htmlspecialchars($item['href']) ?>">
                <span class="menu-icon" aria-hidden="true">
                    <svg viewBox="0 0 24 24"><?= $item['icon'] ?></svg>
                </span>
                <span><?= htmlspecialchars($item['label']) ?></span>
            </a>
        <?php endforeach; ?>
    </nav>

    <div class="sidebar-account">
        <button class="sidebar-user" type="button" id="sidebarUserTrigger" aria-expanded="false" aria-controls="sidebarUserMenu">
            <span class="profile-avatar"><?= htmlspecialchars($userInitials) ?></span>
            <span class="profile-summary">
                <strong><?= htmlspecialchars($userName) ?></strong>
                <small><?= htmlspecialchars($userHandle) ?></small>
            </span>
            <span class="sidebar-user-chevron" aria-hidden="true">▾</span>
        </button>
        <div class="sidebar-user-menu" id="sidebarUserMenu">
            <a href="Profile.php">Edit Profile</a>
            <a href="../../index.php" class="logout-link">Log out</a>
        </div>
    </div>
</aside>

<script src="../Components/js/Navbar.js"></script>

const menuItems = document.querySelectorAll(".menu-item");

const currentPage = window.location.pathname.split("/").pop();

menuItems.forEach(function (item) {
  const page = item.dataset.page;

  if (page === currentPage) {
    item.classList.add("active");
  }

  item.addEventListener("click", function () {
    if (!page) {
      return;
    }

    window.location.href = page;
  });
});

const profileTrigger = document.getElementById("profileTrigger");
const profileMenu = document.getElementById("profileMenu");

if (profileTrigger && profileMenu) {
  profileTrigger.addEventListener("click", function (event) {
    event.stopPropagation();

    profileMenu.classList.toggle("open");
  });

  document.addEventListener("click", function (event) {
    if (
      !profileMenu.contains(event.target) &&
      !profileTrigger.contains(event.target)
    ) {
      profileMenu.classList.remove("open");
    }
  });
}

const sidebarUserTrigger = document.getElementById("sidebarUserTrigger");
const sidebarUserMenu = document.getElementById("sidebarUserMenu");

if (sidebarUserTrigger && sidebarUserMenu) {
  sidebarUserTrigger.addEventListener("click", function () {
    const isOpen = sidebarUserMenu.classList.toggle("open");
    sidebarUserTrigger.setAttribute("aria-expanded", String(isOpen));
  });

  document.addEventListener("click", function (event) {
    if (
      !sidebarUserMenu.contains(event.target) &&
      !sidebarUserTrigger.contains(event.target)
    ) {
      sidebarUserMenu.classList.remove("open");
      sidebarUserTrigger.setAttribute("aria-expanded", "false");
    }
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape" && sidebarUserMenu.classList.contains("open")) {
      sidebarUserMenu.classList.remove("open");
      sidebarUserTrigger.setAttribute("aria-expanded", "false");
      sidebarUserTrigger.focus();
    }
  });
}

const layoutToggle = document.querySelector("[data-layout-toggle]");
const layoutRole = document.querySelector("[data-layout-role]");
const roleSidebar = document.querySelector(".role-sidebar");

if (roleSidebar) {
  document.body.classList.add("has-role-sidebar");
}

if (layoutToggle && layoutRole) {
  layoutToggle.addEventListener("click", function (event) {
    event.preventDefault();
    const layout = layoutToggle.dataset.layoutToggle;
    document.cookie = `${layoutRole.dataset.layoutRole}_layout=${layout}; path=/; max-age=31536000; SameSite=Lax`;
    window.location.reload();
  });
}

<?php
/* ------------------------------------------------------------
   SHARED ADMIN LAYOUT HELPERS
   Used by every page in Admin/Pages so the <head>, navbar,
   page header and common widgets are written only once.
   ------------------------------------------------------------ */

/** Escape output (short helper to keep templates readable). */
function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

/** Current admin identity: [full name, role label, initials]. */
function adminUser(): array
{
    return ['Admin User', 'Administrator', 'AU'];
}

/** Opens the document: <head>, shared base.css + page CSS, <body> and the navbar/sidebar. */
function renderHead(string $title, string $pageCss): void
{
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title) ?></title>
    <link rel="stylesheet" href="../Components/css/base.css">
    <link rel="stylesheet" href="../Components/css/<?= e($pageCss) ?>">
</head>
<body>
<?php
    include __DIR__ . '/Navbar.php';
}

/** The blue banner at the top of every page. */
function renderPageHeader(string $title, string $subtitle = 'Maintenance Reporting Portal'): void
{
    [$userName] = adminUser();
    ?>
    <header class="page-header">
        <div>
            <h1><?= e($title) ?></h1>
            <p><?= e($subtitle) ?></p>
        </div>
        <span class="admin-user"><?= e($userName) ?></span>
    </header>
<?php
}

/** Closes the document. */
function renderFoot(): void
{
    ?>
</body>
</html>
<?php
}

/** Coloured status pill: "In Progress" -> <span class="status in-progress">. */
function statusBadge(string $status): string
{
    $class = strtolower(str_replace(' ', '-', $status));
    return '<span class="status ' . e($class) . '">' . e($status) . '</span>';
}

/** "1 open task" / "3 open tasks". */
function openTasksLabel(int $count): string
{
    return $count . ' open ' . ($count === 1 ? 'task' : 'tasks');
}

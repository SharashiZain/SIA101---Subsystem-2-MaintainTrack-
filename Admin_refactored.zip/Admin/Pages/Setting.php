<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selectedLayout = $_POST['admin_layout'] ?? '';

    if (in_array($selectedLayout, ['sidebar', 'navbar'], true)) {
        setcookie('admin_layout', $selectedLayout, [
            'expires' => time() + (365 * 24 * 60 * 60),
            'path' => '/',
            'samesite' => 'Lax',
        ]);
        header('Location: Setting.php?saved=1');
        exit;
    }
}

$currentLayout = $_COOKIE['admin_layout'] ?? 'sidebar';
if (!in_array($currentLayout, ['sidebar', 'navbar'], true)) {
    $currentLayout = 'sidebar';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Settings</title>
    <link rel="stylesheet" href="../Components/css/Setting.css">
</head>
<body>
    <?php include '../Components/Navbar.php'; ?>

    <main class="admin-settings">
        <header class="settings-heading">
            <div>
                <p class="settings-eyebrow">ADMINISTRATION</p>
                <h1>Settings</h1>
                <p class="settings-description">Choose how you want to navigate the admin workspace.</p>
            </div>
        </header>

        <section class="settings-panel" aria-labelledby="navigation-setting-title">
            <div class="settings-panel-heading">
                <h2 id="navigation-setting-title">Navigation</h2>
                <p>Your preference will be remembered on this device.</p>
            </div>

            <form method="post" action="Setting.php" class="settings-form">
                <div class="settings-field">
                    <label for="admin-layout">Navigation layout</label>
                    <select id="admin-layout" name="admin_layout">
                        <option value="sidebar" <?= $currentLayout === 'sidebar' ? 'selected' : '' ?>>Sidebar</option>
                        <option value="navbar" <?= $currentLayout === 'navbar' ? 'selected' : '' ?>>Top navigation</option>
                    </select>
                </div>

                <button type="submit" class="settings-save">Save preference</button>
            </form>

            <?php if (isset($_GET['saved'])): ?>
                <p class="settings-status" role="status">Navigation preference saved.</p>
            <?php endif; ?>
        </section>
    </main>
</body>
</html>

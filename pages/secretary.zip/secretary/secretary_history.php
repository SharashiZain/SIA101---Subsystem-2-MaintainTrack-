<?php
require_once __DIR__ . '/../../Config/supabase.php';
require_once __DIR__ . '/../../Components/layout.php';

/* =========================================================
   Supabase helper (server-side only)
   Uses the secret key so row-level security does not hide rows from
   this admin page. The key stays in PHP and is never sent to the browser.
========================================================= */
function historyRest(string $path): array
{
    if (!function_exists('curl_init')) {
        return ['ok' => false, 'data' => null];
    }

    $ch = curl_init(rtrim(SUPABASE_URL, '/') . $path);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => [
            'apikey: ' . SUPABASE_SECRET_KEY,
            'Accept: application/json',
        ],
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT        => 30,
    ]);
    $response = curl_exec($ch);
    $status   = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($response === false) {
        return ['ok' => false, 'data' => null];
    }

    return [
        'ok'   => $status >= 200 && $status < 300,
        'data' => json_decode($response, true),
    ];
}

/* =========================================================
   Data (every request the secretary has approved or rejected)
========================================================= */
$history = [];
$loadError = '';

$reqRes = historyRest(
    '/rest/v1/maintenance_requests'
    . '?select=display_id,concern,reported_by,date_reported,approval_status,approval_date,rejection_reason,created_at'
    . '&approval_status=in.(Approved,Rejected)'
    . '&order=approval_date.desc.nullslast,created_at.desc'
);
$usrRes = historyRest('/rest/v1/users?select=user_id,full_name');

if (!$reqRes['ok'] || !is_array($reqRes['data'])) {
    $loadError = 'Could not load history from the database.';
} else {
    $users = [];
    if ($usrRes['ok'] && is_array($usrRes['data'])) {
        foreach ($usrRes['data'] as $u) $users[$u['user_id']] = $u['full_name'];
    }

    $manila = new DateTimeZone('Asia/Manila');
    $formatDate = function (?string $value) use ($manila): string {
        if (empty($value)) return '';
        $dt = new DateTime($value);
        $dt->setTimezone($manila);
        return $dt->format('M j, Y');
    };

    foreach ($reqRes['data'] as $row) {
        $decision = $row['approval_status']; // Approved | Rejected

        $history[] = [
            'id'          => $row['display_id'],
            'title'       => $row['concern'],
            'submitter'   => $users[$row['reported_by'] ?? ''] ?? 'Unknown',
            'date'        => $formatDate($row['date_reported'] ?? null),
            'decidedOn'   => $formatDate($row['approval_date'] ?? null),
            'reason'      => $row['rejection_reason'] ?? '',
            'decision'    => $decision,
            'decisionKey' => strtolower($decision),
        ];
    }
}

renderHead('History', 'History.css', 'secretary');
?>
<div class="page">

    <!-- ONE CONTAINER: header + all page content live in one card -->
    <div class="one-card">

    <?php renderPageHeader('History', 'Previously reviewed submissions', 'secretary'); ?>

    <section class="panel">
        <div class="panel-head">
            <h2>Reviewed Submissions</h2>
        </div>

        <?php if ($loadError): ?>
            <div style="padding: 14px 18px; margin-bottom: 14px; border-radius: 10px; background: #fee2e2; color: #991b1b; font-size: 13px; font-weight: 600;">
                <?= e($loadError) ?>
            </div>
        <?php endif; ?>

        <div class="history-list">
            <?php foreach ($history as $item): ?>
                <div class="history-card" data-decision="<?= e($item['decisionKey']) ?>" data-id="<?= e($item['id']) ?>">
                    <div class="history-main">
                        <div class="history-id"><?= e($item['id']) ?></div>
                        <div class="history-title"><?= e($item['title']) ?></div>
                        <div class="history-meta">
                            Submitted by <?= e($item['submitter']) ?> · <?= e($item['date']) ?>
                            <?php if ($item['decidedOn'] !== ''): ?>
                                · <?= e($item['decision']) ?> on <?= e($item['decidedOn']) ?>
                            <?php endif; ?>
                            <?php if ($item['decisionKey'] === 'rejected' && $item['reason'] !== ''): ?>
                                · Reason: <?= e($item['reason']) ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="history-side">
                        <span class="status-pill status-<?= e($item['decisionKey']) ?>"><?= e($item['decision']) ?></span>
                    </div>
                </div>
            <?php endforeach; ?>

            <?php if (empty($history) && !$loadError): ?>
                <div style="text-align: center; padding: 30px; color: #687985; font-size: 14px; font-weight: 600;">
                    No approved or rejected requests yet.
                </div>
            <?php endif; ?>
        </div>
    </section>

    </div><!-- /.one-card -->
</div>
<script>
    /* When opened from a notification (?id=MT-00133&highlight=1), scroll to that request and flash it. */
    document.addEventListener('DOMContentLoaded', function () {
        const params = new URLSearchParams(window.location.search);
        const id = params.get('id');
        if (params.get('highlight') !== '1' || !id) return;

        const target = document.querySelector('.history-card[data-id="' + CSS.escape(id) + '"]');
        if (!target) return;

        setTimeout(function () {
            target.scrollIntoView({ behavior: 'smooth', block: 'center' });
            target.animate([
                { boxShadow: '0 0 0 0 rgba(23, 105, 170, 0.55)', backgroundColor: '#dbeafe' },
                { boxShadow: '0 0 0 10px rgba(23, 105, 170, 0.25)', backgroundColor: '#e8f1fb', offset: 0.4 },
                { boxShadow: '0 0 0 0 rgba(23, 105, 170, 0)', backgroundColor: '#ffffff' }
            ], { duration: 2500, easing: 'ease-out' });
        }, 300);
    });
</script>
<?php renderFoot(); ?>
</html>
<link rel="stylesheet" href="../../Components/css/Sidebar.css">

<aside class="role-sidebar" data-layout-role="regular" aria-label="Regular user navigation">
    <a class="sidebar-brand" href="reg_user_dashboard.php">
        <span class="sidebar-brand-mark"><img src="../../Components/img/logo.png" alt=""></span>
        <span>MaintainTrack</span>
    </a>

    <nav class="sidebar-menu" aria-label="Main navigation">
        <a href="reg_user_dashboard.php" class="menu-item" data-page="reg_user_dashboard.php">
            <span class="menu-icon"><svg viewBox="0 0 24 24"><path d="M3 10.5 12 3l9 7.5M5 9.5V21h14V9.5M9 21v-7h6v7"/></svg></span>
            <span>Dashboard</span>
        </a>
        <a href="Report.php" class="menu-item" data-page="Report.php">
            <span class="menu-icon"><svg viewBox="0 0 24 24"><path d="M4 5h16v14H4zM8 9h8M8 13h5"/></svg></span>
            <span>Reports</span>
        </a>
        <a href="History.php" class="menu-item" data-page="History.php">
            <span class="menu-icon"><svg viewBox="0 0 24 24"><path d="M3 12a9 9 0 1 0 9-9M3 4v8h8"/></svg></span>
            <span>History</span>
        </a>
        <a href="Request.php" class="menu-item" data-page="Request.php">
            <span class="menu-icon"><svg viewBox="0 0 24 24"><path d="M4 5h16v14H4zM8 12h8M12 8v8"/></svg></span>
            <span>Request</span>
        </a>
        <a href="Notification.php" class="menu-item" data-page="Notification.php">
            <span class="menu-icon"><svg viewBox="0 0 24 24"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></svg><span class="notification-dot"></span></span>
            <span>Notification</span>
        </a>
        <a href="Maintenance.php" class="menu-item" data-page="Maintenance.php">
            <span class="menu-icon"><svg viewBox="0 0 24 24"><path d="M12 3v18M5 8h14M5 16h14M7 3h10"/></svg></span>
            <span>Maintenance</span>
        </a>
    </nav>

    <div class="sidebar-account">
        <div class="sidebar-user">
            <span class="profile-avatar">JD</span>
            <span class="profile-summary"><strong>Juan Dela Cruz</strong><small>Regular User</small></span>
        </div>
        <a href="Profile.php">Edit Profile</a>
        <a href="../../index.php" class="logout-link">Log out</a>
        <a href="#" class="layout-choice" data-layout-toggle="navbar">Use top navigation</a>
    </div>
</aside>

<script src="../Components/js/Navbar.js"></script>

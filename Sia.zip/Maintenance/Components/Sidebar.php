<link rel="stylesheet" href="../../Components/css/Sidebar.css">

<aside class="role-sidebar" data-layout-role="maintenance" aria-label="Maintenance navigation">
    <a class="sidebar-brand" href="Dashboard.php">
        <span class="sidebar-brand-mark" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none"><path d="M12 2L3 7v6c0 5 4 8.5 9 9 5-.5 9-4 9-9V7l-9-5z"/><path d="M9 12l2 2 4-4"/></svg>
        </span>
        <span>MaintainTrack</span>
    </a>

    <nav class="sidebar-menu" aria-label="Main navigation">
        <a href="Dashboard.php" class="menu-item" data-page="Dashboard.php">
            <span class="menu-icon"><svg viewBox="0 0 24 24" fill="none"><path d="M3 11l9-7 9 7"/><path d="M5 10v9a1 1 0 001 1h4v-6h4v6h4a1 1 0 001-1v-9"/></svg></span>
            <span>Dashboard</span>
        </a>
        <a href="Facility.php" class="menu-item" data-page="Facility.php">
            <span class="menu-icon"><svg viewBox="0 0 24 24" fill="none"><rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 3h6v3H9zM8 11h8M8 15h5"/></svg></span>
            <span>Facility</span>
        </a>
        <a href="Task.php" class="menu-item" data-page="Task.php">
            <span class="menu-icon"><svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="8.5"/><path d="M12 8v4l3 2"/></svg></span>
            <span>Task</span>
        </a>
        <a href="Request.php" class="menu-item" data-page="Request.php">
            <span class="menu-icon"><svg viewBox="0 0 24 24" fill="none"><path d="M6 4v16M6 4l4 2-4 2M18 20V4M18 20l-4-2 4-2"/></svg></span>
            <span>Request</span>
        </a>
        <a href="Notification.php" class="menu-item" data-page="Notification.php">
            <span class="menu-icon"><svg viewBox="0 0 24 24" fill="none"><path d="M6 8a6 6 0 0112 0c0 4 1.5 5.5 2 6H4c.5-.5 2-2 2-6z"/><path d="M10 20a2 2 0 004 0"/></svg></span>
            <span>Notification</span>
            <span class="menu-badge">3</span>
        </a>
    </nav>

    <div class="sidebar-account">
        <div class="sidebar-user">
            <span class="profile-avatar">JM</span>
            <span class="profile-summary"><strong>Jose Mar</strong><small>Maintenance</small></span>
        </div>
        <a href="Profile.php">Edit Profile</a>
        <a href="../../index.php" class="logout-link">Log out</a>
        <a href="#" class="layout-choice" data-layout-toggle="navbar">Use top navigation</a>
    </div>
</aside>

<script src="../Components/js/NavBar.js"></script>
